export class Teacher{
    teacherId : number=0;
    teacherName : string="";
    teachingsubject : string ="";
    salary : any;
   
}