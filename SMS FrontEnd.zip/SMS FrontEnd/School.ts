export class School{
    schoolCode : number=0;
    schoolName : string="";
    schoolLocation : string ="";
    schoolFounder : string= "";
    establishedYear : Date;
    principalName : string="";
}